﻿' *****************************************************************
' Team Number: 45
' Team Member 1 Details: Bench, L (220138718)
' Team Member 2 Details: Evans, MR (220021998)
' Team Member 3 Details: Surname, Initials (Student #)
' Team Member 4 Details: e.g. Smith, J (202000001)
' Practical: Team Project
' Class name: SeedCompany
' *****************************************************************
Option Infer Off
Option Strict On
Option Explicit On
Public Class SeedCompany
    Implements ICompany

    Public Function NetProfit() As Double Implements ICompany.NetProfit
        Throw New NotImplementedException()
    End Function

    Public Function Revenue() As Double Implements ICompany.Revenue
        Throw New NotImplementedException()
    End Function

    Public Function InvestmentAmount() As Double Implements ICompany.InvestmentAmount
        Throw New NotImplementedException()
    End Function

    Public Function PercentageInvestment() As Double Implements ICompany.PercentageInvestment
        Throw New NotImplementedException()
    End Function
End Class
