﻿' *****************************************************************
' Team Number: 45
' Team Member 1 Details: Bench, L (220138718)
' Team Member 2 Details: Evans, MR (220021998)
' Team Member 3 Details: Surname, Initials (Student #)
' Team Member 4 Details: e.g. Smith, J (202000001)
' Practical: Team Project
' Class name: frmInvestments
' *****************************************************************

Public Class frmInvestments

    'Enumeration for Expertise type
    Public Enum ExpertiseType
        Computer = 1
        Food = 2
        Education = 3
        Construction = 4
        Health = 5
        Transport = 6
    End Enum


    'Enum for the user type 
    Public Enum UserType
        SeedCompany = 1
        Investor = 2
    End Enum


End Class

