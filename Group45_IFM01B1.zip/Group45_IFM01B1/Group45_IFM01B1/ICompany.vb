﻿' *****************************************************************
' Team Number: 45
' Team Member 1 Details: Bench, L (220138718)
' Team Member 2 Details: Surname, Initials (Student #)
' Team Member 3 Details: Surname, Initials (Student #)
' Team Member 4 Details: e.g. Smith, J (202000001)
' Practical: Team Project
' Class name: (name of the class)
' *****************************************************************
Option Infer Off
Option Strict On
Option Explicit On
Public Interface ICompany

End Interface
