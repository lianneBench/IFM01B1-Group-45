﻿' *****************************************************************
' Team Number: 45
' Team Member 1 Details: Bench, L (220138718)
' Team Member 2 Details: Evans, MR (220021998)
' Team Member 3 Details: Mahlabe, KH(219020791)
' Team Member 4 Details: Zulu, P(215002544)
' Practical: Team Project
' Class name: ICompany
' *****************************************************************
Option Infer Off
Option Strict On
Option Explicit On
Public Interface ICompany
    'No variables

    'Methods:
    Property NetProfit(index As Integer) As Double
    Property Revenue(index As Integer) As Double
    Property InvestmentAmount() As Double
    Property PercentageInvestment() As Double
End Interface
