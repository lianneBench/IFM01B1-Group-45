﻿' *****************************************************************
' Team Number: 45
' Team Member 1 Details: Bench, L (220138718)
' Team Member 2 Details: Evans, MR (220021998)
' Team Member 3 Details: Mahlabe, KH(219020791)
' Team Member 4 Details: Zulu, P(215002544)
' Practical: Team Project
' Class name: Investor
' *****************************************************************
Option Infer Off
Option Strict On
Option Explicit On
<Serializable> Public Class Investor
    Inherits Person
    'attributes 
    Private _Name As String
    Private _Surname As String
    Private _SeedAmount As Double
    Private _isMale As Boolean
    Private _Age As Integer

    'constructor
    Public Sub New(email As String, num As String, coun As String, experNum As Integer, story As String)
        MyBase.New(email, num, coun, experNum, story)
    End Sub

    'property methods
    Public Property name As String
        Get
            Return _Name
        End Get
        Set(value As String)
            _Name = value
        End Set
    End Property

    Public Property surname As String
        Get
            Return _Surname
        End Get
        Set(value As String)
            _Surname = value
        End Set
    End Property

    Public Property seedamount As Double
        Get
            Return _SeedAmount
        End Get
        Set(value As Double)
            _SeedAmount = value
        End Set
    End Property

    Public Property age As Integer
        Get
            Return _Age
        End Get
        Set(value As Integer)
            If (value < 0) Then
                _Age = 1
            Else
                _Age = value
            End If
        End Set
    End Property

    Public Property ismale As Boolean
        Get
            Return _isMale
        End Get
        Set(value As Boolean)
            _isMale = value
        End Set
    End Property
    'methods 
    Public Function gender() As String
        Dim tempGender As String = ""
        If ismale = True Then
            tempGender = "Male"
        Else
            tempGender = "Female"
        End If
        Return tempGender
    End Function
    Public Overrides Function Display() As String
        Return "Fullname: " & _Name & " " & _Surname & Environment.NewLine & "Gender: " & gender() & Environment.NewLine & "Age: " & _Age & Environment.NewLine & MyBase.Display()
    End Function
End Class
