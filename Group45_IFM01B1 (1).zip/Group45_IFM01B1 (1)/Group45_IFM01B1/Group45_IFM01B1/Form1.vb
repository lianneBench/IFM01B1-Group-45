﻿' *****************************************************************
' Team Number: 45
' Team Member 1 Details: Bench, L (220138718)
' Team Member 2 Details: Evans, MR (220021998)
' Team Member 3 Details: Mahlabe, KH(219020791)
' Team Member 4 Details: Zulu, P(215002544)
' Practical: Team Project
' Class name: frmInvestments
' *****************************************************************
Option Infer Off
Option Strict On
Option Explicit On

Imports System.IO
Imports System.Runtime.Serialization.Formatters.Binary
Public Class frmInvestments
    Private objPeople() As Person 'stores an array of the default seed companies or investors

    Private Filename As String
    Private BF As BinaryFormatter
    Private FS As FileStream

    'Enumeration for Expertise type
    Public Enum ExpertiseType
        Computer = 1
        Food = 2
        Education = 3
        Construction = 4
        Health = 5
        Transport = 6
    End Enum

    'Enum for the user type 
    Public Enum UserType
        SeedCompany = 1
        Investor = 2
    End Enum

    Private Sub setSeedCompanyInformation(Index As Integer, email As String, phone As String, country As String, experience As ExpertiseType _
            , companyStory As String, companyName As String, foundName As String, netProfit() As Double _
            , revenue() As Double, investAmount As Double, percentage As Double)
        'creates a tempory seed company object to store default values into the array of Person for the textfile
        Dim tempSeed As SeedCompany
        tempSeed = New SeedCompany(email, phone, country, experience, companyStory, companyName, foundName) 'constructor sets the values
        'sets the default seed comany informationn 
        tempSeed.NetProfit(1) = netProfit(1)
        tempSeed.NetProfit(2) = netProfit(2)
        tempSeed.Revenue(1) = revenue(1)
        tempSeed.Revenue(2) = revenue(2)
        tempSeed.InvestmentAmount = investAmount
        tempSeed.PercentageInvestment = percentage
        objPeople(Index) = tempSeed 'upcasting 
    End Sub
    Private Sub setInvestorInformation(index As Integer, email As String, phone As String, country As String, experience As ExpertiseType _
            , companyStory As String, name As String, surname As String, seedamo As Double, isMal As Boolean, age As Integer)
        'creates a tempory investor object to store default values into the array of Person for the textfile
        Dim tempInvestor As Investor
        tempInvestor = New Investor(email, phone, country, experience, companyStory)
        tempInvestor.name = name
        tempInvestor.surname = surname
        tempInvestor.seedamount = seedamo
        tempInvestor.ismale = isMal
        tempInvestor.age = age
        objPeople(index) = tempInvestor ' upcasting 
    End Sub
    Private Sub setDefaultFileValues()
        'Creates default values for the object created and these will be used in the file
        ReDim objPeople(7)
        'Person 1 -investor
        setInvestorInformation(1, "billgates@gmail.com", "0990987876", "USA", ExpertiseType.Computer _
            , "I worked extremely hard in the computer industry and constantly tried to make and keep contacts. I am the co-founder of Microsoft." _
              , "Bill", "Gates", 500000, True, 64)
        'person 2 - investor
        setInvestorInformation(2, "pat.billing@outlook.com", "00982883728", "USA", ExpertiseType.Construction _
            , "I received a patent in 1997 for a fire resistant building material called Geobond.", "Pat", "Billing", 70000, False, 73)
        'Person 3 - seed company
        Dim netProfit(2) As Double
        netProfit(1) = 798273
        netProfit(2) = 505632.65
        Dim revenue(2) As Double
        revenue(1) = 1345562
        revenue(2) = 1098882
        setSeedCompanyInformation(3, "gillianRobbinson@vodamail.com", "0829839922", "South Africa", ExpertiseType.Education _
             , "TeachMe2 has spent 11 years perfecting their services for what their clients’ children need to succeed. They offer tutors for Maths, Accounting, Science, Language, English and Statistics. They also have tutors throughout the country in most of the subjects ready to help any student" _
               , "TeachMe2", "Gillian Robbinson", netProfit, revenue, 300000, 15)
        'person 4 - investor
        setInvestorInformation(4, "wanggang@gmail.com", "9829993882", "China", ExpertiseType.Food _
           , "I have 5 million followers across Xigua Video, bilibili, Weibo, and YouTube as of 2018, and have been praised for my simple, levelheaded approach to cooking." _
             , "Wang", "Gang", 100000, True, 31)
        'Person 5 - seed company 
        netProfit(1) = 23500
        netProfit(2) = 26504
        revenue(1) = 145655
        revenue(2) = 154332
        setSeedCompanyInformation(5, "LearningTools@happy.com", "0829839922", "Portagual", ExpertiseType.Education _
            , "The products sold by learning tools are sourced both locally and internationally, and the founder Sarah Ohlson de Fine, a qualified teacher, personally vets all the products for both quality and efficiency." _
              , "Learning Tools", "Sarah Ohlson de Fine", netProfit, revenue, 500000, 25)
        'person 6  - investor 
        setInvestorInformation(6, "billgates@gmail.com", "0990987876", "USA", ExpertiseType.Health _
            , "I worked extremely hard in the computer industry and constantly tried to make and keep contacts. I am the co-founder of Microsoft." _
              , "Bill", "Gates", 200000, True, 64)
        'person 7 - investor 
        setInvestorInformation(7, "pat.billing@outlook.com", "00982883728", "USA", ExpertiseType.Computer _
            , "I received a patent in 1997 for a fire resistant building material called Geobond.", "Pat", "Billing", 650000, False, 73)
    End Sub
    Private Sub createFile()
        'Sets up the file with default investors or seed companies (This is called for testing and marking purposes)
        setDefaultFileValues()
        Filename = "Group45.ipd"
        'create the file
        FS = New FileStream(Filename, FileMode.Create, FileAccess.ReadWrite)
        'write/save to file 
        BF = New BinaryFormatter()
        For i As Integer = 1 To objPeople.Length - 1
            If TypeOf objPeople(i) Is SeedCompany Then
                Dim tempPerson As SeedCompany
                tempPerson = DirectCast(objPeople(i), SeedCompany)
                BF.Serialize(FS, tempPerson)
            Else
                Dim tempPerson As Investor
                tempPerson = DirectCast(objPeople(i), Investor)
                BF.Serialize(FS, tempPerson)
            End If
        Next i
        'close file
        FS.Close()
        BF = Nothing
        FS = Nothing
        MsgBox("Entries have been added")
    End Sub

End Class

