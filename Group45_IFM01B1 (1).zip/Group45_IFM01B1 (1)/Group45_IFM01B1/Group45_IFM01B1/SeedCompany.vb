﻿' *****************************************************************
' Team Number: 45
' Team Member 1 Details: Bench, L (220138718)
' Team Member 2 Details: Evans, MR (220021998)
' Team Member 3 Details: Mahlabe, KH(219020791)
' Team Member 4 Details: Zulu, P(215002544)
' Practical: Team Project
' Class name: SeedCompany
' *****************************************************************
Option Infer Off
Option Strict On
Option Explicit On
<Serializable> Public Class SeedCompany

    Inherits Person
    Implements ICompany

    'attributes
    Private _CompanyName As String
    Private _FounderFullName As String
    Private _NetProfit() As Double
    Private _Revenue() As Double
    Private _InvestmentAmount As Double
    Private _PercentageInvestment As Double

    'constructor
    Public Sub New(email As String, num As String, coun As String, experNum As Integer, story As String, CompName As String, FFname As String)
        MyBase.New(email, num, coun, experNum, story)
        _CompanyName = CompName
        _FounderFullName = FFname
        'set the array sizes 
        ReDim _NetProfit(2)
        ReDim _Revenue(2)
    End Sub

    'property methods
    Public Property CompanyName As String
        Get
            Return _CompanyName
        End Get
        Set(value As String)
            _CompanyName = value
        End Set
    End Property

    Public Property FounderFullName As String
        Get
            Return _FounderFullName
        End Get
        Set(value As String)
            _FounderFullName = value
        End Set
    End Property

    Public Property NetProfit(index As Integer) As Double Implements ICompany.NetProfit
        Get
            Return _NetProfit(index)
        End Get
        Set(value As Double)
            If (value < 0) Then
                _NetProfit(index) = 0
            Else
                _NetProfit(index) = value
            End If
        End Set
    End Property

    Public Property Revenue(index As Integer) As Double Implements ICompany.Revenue
        Get
            Return _Revenue(index)
        End Get
        Set(value As Double)
            If (value < 0) Then
                _Revenue(index) = 0
            Else
                _Revenue(index) = value
            End If
        End Set
    End Property

    Public Property InvestmentAmount As Double Implements ICompany.InvestmentAmount
        Get
            Return _InvestmentAmount
        End Get
        Set(value As Double)
            If (value < 0) Then
                _InvestmentAmount = 0
            Else
                _InvestmentAmount = value
            End If
        End Set
    End Property

    Public Property PercentageInvestment As Double Implements ICompany.PercentageInvestment
        Get
            Return _PercentageInvestment
        End Get
        Set(value As Double)
            If (value < 0) Then
                _PercentageInvestment = 0
            Else
                _PercentageInvestment = value
            End If
        End Set
    End Property

    'methods
    Public Function CalculateCostOfSales(index As Integer) As Double
        'calculates the cost of sales 
        Return _Revenue(index) - _NetProfit(index)
    End Function
    Public Overrides Function Display() As String
        Return "Company name: " & _CompanyName & Environment.NewLine & "Founder's name: " & FounderFullName & Environment.NewLine &
            "Revenue this year: " & _Revenue(1) & vbTab & "Revenue last year: " & _Revenue(2) & Environment.NewLine &
            "Cost of sales this year: " & CalculateCostOfSales(1) & vbTab & "Cost of sales last year: " & CalculateCostOfSales(1) & Environment.NewLine &
            "Net profit this year: " & NetProfit(1) & vbTab & "Net profit last year: " & NetProfit(1) & Environment.NewLine &
            "Investment amount: " & _InvestmentAmount & Environment.NewLine & "Percentage of company: " & _PercentageInvestment & Environment.NewLine & MyBase.Display()
    End Function
End Class
