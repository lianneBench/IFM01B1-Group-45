﻿' *****************************************************************
' Team Number: 45
' Team Member 1 Details: Bench, L (220138718)
' Team Member 2 Details: Surname, Initials (Student #)
' Team Member 3 Details: Surname, Initials (Student #)
' Team Member 4 Details: e.g. Smith, J (202000001)
' Practical: Team Project
' Class name: (name of the class)
' *****************************************************************
Option Infer Off
Option Strict On
Option Explicit On
Public Class Person
    'Enumeration for Expertise type
    Public Enum ExpertiseType
        Computer = 1
        Food = 2
        Education = 3
        Construction = 4
        Health = 5
        Transport = 6
    End Enum
    'Attributes 
    Private _EmailAddress As String
    Private _PhoneNum As String
    Private _Country As String
    Private _Expertise() As Integer
    Private _CompanyStory As String
    'Constructor
    Public Sub New(email As String, num As String, coun As String, experNum As Integer)
        _EmailAddress = email
        _PhoneNum = num
        _Country = coun
        setExpertiseArraySize(experNum)
    End Sub
    'Property Methods 
    Public Overridable Property EmailAddress() As String
        Get
            Return _EmailAddress
        End Get
        Set(value As String)
            _EmailAddress = value
        End Set
    End Property
    Public Overridable Property PhoneNum() As String
        Get
            Return _PhoneNum
        End Get
        Set(value As String)
            If (value.Length > 5) Then 'makes sure the phone number is more than 5 
                _PhoneNum = value
            Else
                _PhoneNum = "Invalid phone number."
            End If
        End Set
    End Property
    Public Overridable Property Country() As String
        Get
            Return _Country
        End Get
        Set(value As String)
            _Country = value
        End Set
    End Property
    Public Overridable Property Expertise(index As Integer) As Integer
        Get
            Return _Expertise(index)
        End Get
        Set(value As Integer)
            _Expertise(index) = value
        End Set
    End Property
    Public Overridable Property CompanyStory() As String
        Get
            Return _CompanyStory
        End Get
        Set(value As String)
            _CompanyStory = value
        End Set
    End Property
    'Other Methods 
    Public Sub setExpertiseArraySize(value As Integer)
        ReDim _Expertise(value)
    End Sub
    Public Function DetermineExpertise() As String
        'determines and displays a string of expertise 
        Dim display As String
        display = ""
        For i As Integer = 1 To _Expertise.Length
            Select Case _Expertise(i)
                Case ExpertiseType.Computer
                    display += "Computers and Electronics"
                Case ExpertiseType.Food
                    display += "Agricultural"
                Case ExpertiseType.Education
                    display += "Education"
                Case ExpertiseType.Construction
                    display += "Construction"
                Case ExpertiseType.Health
                    display += "Pharmaceutical and Health Care"
                Case ExpertiseType.Transport
                    display += "Transport"
            End Select
            display += ", "
        Next
        Return display
    End Function
    Public Function Display() As String
        'Displays the information
        Return "Email address:" & _EmailAddress & Environment.NewLine & "Phone Number: " & _PhoneNum & Environment.NewLine & "Country: " & _Country & Environment.NewLine &
            "Expertise:" & DetermineExpertise() & Environment.NewLine & "Company Story: " & _CompanyStory
    End Function
End Class
